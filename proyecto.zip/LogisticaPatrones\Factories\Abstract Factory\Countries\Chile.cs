public class Chile(): ConfiguracionPais
{
    
}