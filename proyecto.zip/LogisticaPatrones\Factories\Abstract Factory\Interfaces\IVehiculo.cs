public interface IVehiculo
{
}