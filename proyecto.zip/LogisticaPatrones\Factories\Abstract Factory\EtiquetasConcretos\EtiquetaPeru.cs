public class EtiquetaPeru : IEtiqueta
{
}