public interface IEtiqueta
{
}