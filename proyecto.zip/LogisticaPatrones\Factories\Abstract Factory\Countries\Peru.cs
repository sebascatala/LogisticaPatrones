public class Peru(): ConfiguracionPais
{
    
}