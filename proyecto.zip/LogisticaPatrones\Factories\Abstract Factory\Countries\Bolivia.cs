public class Bolivia(): ConfiguracionPais
{
    
}