public interface IAlmacen
{
}