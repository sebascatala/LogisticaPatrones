public class EtiquetaChile : IEtiqueta
{
}