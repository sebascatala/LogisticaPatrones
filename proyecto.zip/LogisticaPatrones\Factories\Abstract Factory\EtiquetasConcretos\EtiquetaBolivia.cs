public class EtiquetaBolivia : IEtiqueta
{
}